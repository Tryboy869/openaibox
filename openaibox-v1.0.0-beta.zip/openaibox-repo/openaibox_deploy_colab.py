#!/usr/bin/env python3
"""
openaibox_deploy.py — Colab Deployment Script
=================================================

Run this script in Google Colab to:
  1. Upload the repo ZIP
  2. Build the package
  3. Test it on SmolLM-360M
  4. Create GitHub repo + push
  5. Create GitHub release
  6. Publish to PyPI
  7. Display final links

Usage in Colab:
  !python openaibox_deploy.py
"""

import os
import sys
import json
import shutil
import subprocess


# ════════════════════════════════════════════════════════════
# SECTION 0 — TOKENS (paste yours here before running)
# ════════════════════════════════════════════════════════════

GITHUB_TOKEN = "PASTE_YOUR_GITHUB_TOKEN_HERE"
PYPI_TOKEN   = "PASTE_YOUR_PYPI_TOKEN_HERE"
GITHUB_USER  = "tryboy869"
REPO_NAME    = "openaibox"

# ════════════════════════════════════════════════════════════


def run(cmd, check=True, capture=False, env=None):
    """Run a shell command."""
    full_env = {**os.environ, **(env or {})}
    result = subprocess.run(
        cmd, shell=True, check=check,
        capture_output=capture, text=True, env=full_env
    )
    if capture:
        return result.stdout.strip()
    return result


def section(title):
    print(f"\n{'═'*60}")
    print(f"  {title}")
    print(f"{'═'*60}")


def ok(msg):
    print(f"  ✅ {msg}")


def log(msg):
    print(f"  ›  {msg}")


# ════════════════════════════════════════════════════════════
# SECTION 1 — Install dependencies
# ════════════════════════════════════════════════════════════

section("SECTION 1 — Installing dependencies")

run("pip install -q transformers torch build twine requests setuptools wheel")
run("pip install -q 'gh' || apt-get install -y gh || true")   # GitHub CLI (best-effort)
ok("Dependencies installed")


# ════════════════════════════════════════════════════════════
# SECTION 2 — Upload ZIP via Colab file picker
# ════════════════════════════════════════════════════════════

section("SECTION 2 — Upload repo ZIP")

try:
    from google.colab import files as colab_files

    log("A file picker will appear below.")
    log("Upload the openaibox-v1.0.0-beta.zip file.")

    uploaded = colab_files.upload()

    if not uploaded:
        print("  ❌ No file uploaded. Exiting.")
        sys.exit(1)

    zip_filename = list(uploaded.keys())[0]
    ok(f"Uploaded: {zip_filename}")

except ImportError:
    # Not in Colab — look for zip in current directory
    zips = [f for f in os.listdir(".") if f.endswith(".zip") and "openaibox" in f]
    if not zips:
        print("  ❌ Not in Colab and no openaibox zip found. Exiting.")
        sys.exit(1)
    zip_filename = zips[0]
    ok(f"Found locally: {zip_filename}")


# ════════════════════════════════════════════════════════════
# SECTION 3 — Extract + Build
# ════════════════════════════════════════════════════════════

section("SECTION 3 — Extracting and building")

# Extract
WORK_DIR = "/content/openaibox-workspace"
os.makedirs(WORK_DIR, exist_ok=True)
run(f"unzip -o '{zip_filename}' -d {WORK_DIR}")
ok("Extracted")

# Find the repo root (first directory inside zip)
entries = [e for e in os.listdir(WORK_DIR) if os.path.isdir(os.path.join(WORK_DIR, e))]
if not entries:
    print("  ❌ Empty zip. Exiting.")
    sys.exit(1)

REPO_DIR = os.path.join(WORK_DIR, entries[0])
log(f"Repo root: {REPO_DIR}")
os.chdir(REPO_DIR)

# Build
result = subprocess.run("python -m build", shell=True, capture_output=True, text=True)
if result.returncode != 0:
    print("  ❌ Build error:")
    print(result.stdout[-2000:])
    print(result.stderr[-2000:])
    sys.exit(1)
ok("Package built")

dist_files = os.listdir("dist")
log(f"dist/ contents: {dist_files}")


# ════════════════════════════════════════════════════════════
# SECTION 4 — Test on SmolLM-360M
# ════════════════════════════════════════════════════════════

section("SECTION 4 — Testing on SmolLM-360M")

# Install the built package locally
whl = next(f for f in dist_files if f.endswith(".whl"))
run(f"pip install dist/{whl} -q")
ok(f"openaibox installed from {whl}")

# Run test script
log("Running validation tests...")
result = subprocess.run(
    [sys.executable, "tests/test_smollm_analysis.py"],
    capture_output=False,
    text=True,
)

if result.returncode != 0:
    print("  ❌ Tests failed. Check output above. Stopping.")
    sys.exit(1)

ok("All tests passed")

# Check that results were saved
results_path = "tests/results/smollm_graph.json"
if os.path.exists(results_path):
    with open(results_path) as f:
        graph = json.load(f)
    ok(f"graph.json generated — hidden_dim={graph['architecture']['hidden_dim']}")

    # Verify expected structure
    assert graph["architecture"]["class"] == "LlamaForCausalLM"
    decision = next(p for p in graph["injection_points"] if p["role"] == "decision")
    ok(f"Decision point confirmed: {decision['layer']} {decision['out_shape']}")
else:
    print("  ⚠ graph.json not found but tests passed — continuing")


# ════════════════════════════════════════════════════════════
# SECTION 5 — Git setup + GitHub repo creation
# ════════════════════════════════════════════════════════════

section("SECTION 5 — Git setup + GitHub repo creation")

# Git config
run('git config --global user.email "anzize.contact@proton.me"')
run('git config --global user.name "Daouda Abdoul Anzize"')

# Init repo
if not os.path.exists(".git"):
    run("git init")
    run("git add .")
    run('git commit -m "feat: initial release — Open AI Box v1.0.0-beta"')
    ok("Git repository initialized")
else:
    run("git add .")
    run('git commit -m "feat: initial release — Open AI Box v1.0.0-beta" --allow-empty')
    ok("Git commit created")

# Create GitHub repo via API
import urllib.request
import urllib.parse

log("Creating GitHub repository...")
api_data = json.dumps({
    "name":        REPO_NAME,
    "description": "Universal LLM introspection. Understand any model. Any architecture.",
    "homepage":    "https://pypi.org/project/openaibox/",
    "has_issues":  True,
    "has_wiki":    False,
    "private":     False,
    "auto_init":   False,
}).encode()

req = urllib.request.Request(
    "https://api.github.com/user/repos",
    data    = api_data,
    headers = {
        "Authorization": f"Bearer {GITHUB_TOKEN}",
        "Content-Type":  "application/json",
        "Accept":        "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    },
    method = "POST",
)

try:
    with urllib.request.urlopen(req) as resp:
        repo_info = json.loads(resp.read())
    REPO_URL = repo_info["clone_url"]
    ok(f"Repository created: {repo_info['html_url']}")
except urllib.error.HTTPError as e:
    body = json.loads(e.read())
    if "already exists" in str(body.get("errors", "")):
        REPO_URL = f"https://github.com/{GITHUB_USER}/{REPO_NAME}.git"
        log("Repository already exists — using existing")
    else:
        print(f"  ❌ GitHub API error: {body}")
        sys.exit(1)

# Set remote + push
AUTH_URL = REPO_URL.replace("https://", f"https://{GITHUB_TOKEN}@")
run(f"git remote remove origin 2>/dev/null || true")
run(f"git remote add origin '{AUTH_URL}'")
run("git branch -M main")
run("git push -u origin main --force")
ok("Code pushed to GitHub")

# Set PYPI_TOKEN as repo secret
log("Setting PYPI_TOKEN as GitHub secret...")
import base64
import json as _json

# Get repo public key
key_req = urllib.request.Request(
    f"https://api.github.com/repos/{GITHUB_USER}/{REPO_NAME}/actions/secrets/public-key",
    headers={
        "Authorization": f"Bearer {GITHUB_TOKEN}",
        "Accept": "application/vnd.github+json",
    }
)
try:
    with urllib.request.urlopen(key_req) as resp:
        key_info = json.loads(resp.read())

    # Encrypt secret with repo public key (using PyNaCl if available)
    try:
        from nacl import encoding, public

        pub_key = public.PublicKey(key_info["key"].encode(), encoding.Base64Encoder())
        sealed  = public.SealedBox(pub_key)
        encrypted = base64.b64encode(
            sealed.encrypt(PYPI_TOKEN.encode())
        ).decode()

        secret_data = json.dumps({
            "encrypted_value": encrypted,
            "key_id": key_info["key_id"],
        }).encode()

        secret_req = urllib.request.Request(
            f"https://api.github.com/repos/{GITHUB_USER}/{REPO_NAME}/actions/secrets/PYPI_TOKEN",
            data    = secret_data,
            headers = {
                "Authorization": f"Bearer {GITHUB_TOKEN}",
                "Content-Type":  "application/json",
                "Accept":        "application/vnd.github+json",
            },
            method = "PUT",
        )
        with urllib.request.urlopen(secret_req):
            pass
        ok("PYPI_TOKEN secret configured in GitHub repo")
    except ImportError:
        log("PyNaCl not available — PYPI_TOKEN secret must be set manually in GitHub Settings")
        log("Go to: Settings → Secrets and variables → Actions → New repository secret")
        log(f"Name: PYPI_TOKEN  Value: {PYPI_TOKEN[:8]}...")
except Exception as e:
    log(f"Could not set secret automatically: {e}")
    log("Set PYPI_TOKEN manually in GitHub repo Settings → Secrets")


# ════════════════════════════════════════════════════════════
# SECTION 6 — GitHub Release
# ════════════════════════════════════════════════════════════

section("SECTION 6 — GitHub Release")

VERSION = "1.0.0-beta"
TAG     = f"v{VERSION}"

# Create tag
run(f"git tag -a {TAG} -m 'Release {TAG}'", check=False)
run(f"git push origin {TAG}", check=False)

# Create release via API
with open("CHANGELOG.md") as f:
    changelog = f.read()

release_notes = changelog.split("## [")[1].split("\n", 1)[1].split("## [")[0].strip()

release_data = json.dumps({
    "tag_name":   TAG,
    "name":       f"Open AI Box {TAG}",
    "body":       release_notes,
    "draft":      False,
    "prerelease": True,
}).encode()

release_req = urllib.request.Request(
    f"https://api.github.com/repos/{GITHUB_USER}/{REPO_NAME}/releases",
    data    = release_data,
    headers = {
        "Authorization": f"Bearer {GITHUB_TOKEN}",
        "Content-Type":  "application/json",
        "Accept":        "application/vnd.github+json",
    },
    method = "POST",
)

try:
    with urllib.request.urlopen(release_req) as resp:
        release_info = json.loads(resp.read())
    ok(f"Release created: {release_info['html_url']}")
    RELEASE_URL = release_info["html_url"]
except urllib.error.HTTPError as e:
    log(f"Release may already exist: {e}")
    RELEASE_URL = f"https://github.com/{GITHUB_USER}/{REPO_NAME}/releases"


# ════════════════════════════════════════════════════════════
# SECTION 7 — Publish to PyPI
# ════════════════════════════════════════════════════════════

section("SECTION 7 — Publishing to PyPI")

env_pypi = {"TWINE_USERNAME": "__token__", "TWINE_PASSWORD": PYPI_TOKEN}
run("pip install twine -q")
run("twine upload dist/* --non-interactive --skip-existing", env=env_pypi)
ok("Published to PyPI")


# ════════════════════════════════════════════════════════════
# SECTION 8 — Final summary
# ════════════════════════════════════════════════════════════

GITHUB_URL = f"https://github.com/{GITHUB_USER}/{REPO_NAME}"
PYPI_URL   = f"https://pypi.org/project/{REPO_NAME}/"

print(f"\n{'█'*60}")
print(f"  🚀 DEPLOYMENT COMPLETE")
print(f"{'█'*60}")
print(f"")
print(f"  📦 PyPI    → {PYPI_URL}")
print(f"  🐙 GitHub  → {GITHUB_URL}")
print(f"  🏷  Release → {RELEASE_URL}")
print(f"")
print(f"  Install with:")
print(f"  pip install openaibox")
print(f"")
print(f"  Test result saved:")
print(f"  {REPO_DIR}/tests/results/smollm_graph.json")
print(f"{'█'*60}\n")
